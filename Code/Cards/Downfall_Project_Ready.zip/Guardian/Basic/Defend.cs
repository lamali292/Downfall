using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Guardian.Basic;

[Pool(typeof(GuardianCardPool))]
public class Defend() : GuardianCardModel(1, CardType.Skill, CardRarity.Basic, TargetType.Self)
{
    // TODO: Implement
}