using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Guardian.Uncommon;

[Pool(typeof(GuardianCardPool))]
public class ShieldSpikes() : GuardianCardModel(2, CardType.Skill, CardRarity.Uncommon, TargetType.Self)
{
    // TODO: Implement
}