using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Guardian.Uncommon;

[Pool(typeof(GuardianCardPool))]
public class Harden() : GuardianCardModel(1, CardType.Power, CardRarity.Uncommon, TargetType.None)
{
    // TODO: Implement
}