using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Collector.Uncommon;

[Pool(typeof(CollectorCardPool))]
public class RagingCall() : CollectorCardModel(2, CardType.Power, CardRarity.Uncommon, TargetType.None)
{
    // TODO: Implement
}