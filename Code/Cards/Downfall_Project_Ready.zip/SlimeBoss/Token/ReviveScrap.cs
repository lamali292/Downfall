using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.SlimeBoss.Token;

[Pool(typeof(TokenCardPool))]
public class ReviveScrap() : SlimeBossCardModel(2, CardType.Skill, CardRarity.Token, TargetType.Self)
{
    // TODO: Implement
}