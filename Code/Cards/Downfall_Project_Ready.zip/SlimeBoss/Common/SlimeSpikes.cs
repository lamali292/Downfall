using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.SlimeBoss.Common;

[Pool(typeof(SlimeBossCardPool))]
public class SlimeSpikes() : SlimeBossCardModel(1, CardType.Skill, CardRarity.Common, TargetType.Self)
{
    // TODO: Implement
}