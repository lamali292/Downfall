using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Automaton.Uncommon;

[Pool(typeof(AutomatonCardPool))]
public class Optimize() : AutomatonCardModel(0, CardType.Power, CardRarity.Uncommon, TargetType.None)
{
    // TODO: Implement
}