using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Automaton.Common;

[Pool(typeof(AutomatonCardPool))]
public class Frontload() : AutomatonCardModel(2, CardType.Skill, CardRarity.Common, TargetType.Self)
{
    // TODO: Implement
}