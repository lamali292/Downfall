using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Automaton.Rare;

[Pool(typeof(AutomatonCardPool))]
public class SummonOrb() : AutomatonCardModel(2, CardType.Power, CardRarity.Rare, TargetType.None)
{
    // TODO: Implement
}