using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Awakened.Uncommon;

[Pool(typeof(AwakenedCardPool))]
public class ChosenVerse() : AwakenedCardModel(1, CardType.Skill, CardRarity.Uncommon, TargetType.Self)
{
    // TODO: Implement
}