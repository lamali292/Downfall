using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Champ.Basic;

[Pool(typeof(ChampCardPool))]
public class Execute() : ChampCardModel(2, CardType.Attack, CardRarity.Basic, TargetType.AnyEnemy)
{
    // TODO: Implement
}