using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Champ.Rare;

[Pool(typeof(ChampCardPool))]
public class DancingMaster() : ChampCardModel(2, CardType.Power, CardRarity.Rare, TargetType.None)
{
    // TODO: Implement
}