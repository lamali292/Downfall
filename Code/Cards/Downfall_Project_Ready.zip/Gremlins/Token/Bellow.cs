using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Gremlins.Token;

[Pool(typeof(TokenCardPool))]
public class Bellow() : GremlinsCardModel(0, CardType.Skill, CardRarity.Token, TargetType.Self)
{
    // TODO: Implement
}