using BaseLib.Utils;
using Downfall.Code.Abstract;
using Downfall.Code.Cards.CardModels;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Downfall.Code.Cards.Gremlins.Rare;

[Pool(typeof(GremlinsCardPool))]
public class BrokenShin() : GremlinsCardModel(2, CardType.Skill, CardRarity.Rare, TargetType.Self)
{
    // TODO: Implement
}